namespace FinanceTracker.Domain.Entities;

public enum MoneyFlowType
{
    Income = 1,
    Expense = 2
}